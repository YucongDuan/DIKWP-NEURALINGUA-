"""DIKWP-NEURALINGUA² reference runtime."""

__version__ = "0.1.0"
