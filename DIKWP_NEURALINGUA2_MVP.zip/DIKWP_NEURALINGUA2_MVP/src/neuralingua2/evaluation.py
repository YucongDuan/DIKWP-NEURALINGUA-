from __future__ import annotations

from typing import Dict

import numpy as np
from sklearn.metrics import accuracy_score
from sklearn.metrics.pairwise import cosine_similarity

from .synthetic import text_bottleneck_reconstruct


def nearest_neighbor_accuracy(reference: np.ndarray, query: np.ndarray) -> float:
    ref = reference / np.clip(np.linalg.norm(reference, axis=1, keepdims=True), 1e-9, None)
    qry = query / np.clip(np.linalg.norm(query, axis=1, keepdims=True), 1e-9, None)
    sim = cosine_similarity(qry, ref)
    return float(np.mean(np.argmax(sim, axis=1) == np.arange(len(query))))


def evaluate_channels(semantic: np.ndarray, rng: np.random.Generator) -> Dict[str, float]:
    # Text: sparse and quantized; latent: full vector with moderate transport noise.
    text = text_bottleneck_reconstruct(semantic, top_k=3, quantization=3)
    latent = semantic + rng.normal(0, 0.035, size=semantic.shape)
    latent = latent / np.clip(np.linalg.norm(latent, axis=1, keepdims=True), 1e-9, None)

    surface_truth = np.argmax(np.abs(semantic[:, :6]), axis=1)
    surface_text = np.argmax(np.abs(text[:, :6]), axis=1)
    surface_latent = np.argmax(np.abs(latent[:, :6]), axis=1)

    # A high-dimensional world-state delta task needs all four dimensions, not just a label.
    delta_truth = semantic[:, 6:10]
    delta_text = text[:, 6:10]
    delta_latent = latent[:, 6:10]
    delta_text_cos = float(np.mean(np.diag(cosine_similarity(delta_truth, delta_text))))
    delta_latent_cos = float(np.mean(np.diag(cosine_similarity(delta_truth, delta_latent))))

    return {
        "surface_text_accuracy": float(accuracy_score(surface_truth, surface_text)),
        "surface_latent_accuracy": float(accuracy_score(surface_truth, surface_latent)),
        "relation_text_retrieval": nearest_neighbor_accuracy(semantic, text),
        "relation_latent_retrieval": nearest_neighbor_accuracy(semantic, latent),
        "world_delta_text_cosine": delta_text_cos,
        "world_delta_latent_cosine": delta_latent_cos,
        "text_roundtrip_cosine": float(np.mean(np.sum(semantic * text, axis=1))),
        "latent_roundtrip_cosine": float(np.mean(np.sum(semantic * latent, axis=1))),
    }


def concept_erasure_invariance(semantic: np.ndarray, relation_ids: list[str]) -> Dict[str, float]:
    # The demo analysis is geometry-based; replacing all glosses with opaque IDs must leave it unchanged.
    original_dist = cosine_similarity(semantic)
    erased_ids = [f"U-{i:04d}" for i in range(len(relation_ids))]
    assert len(erased_ids) == len(relation_ids)
    erased_dist = cosine_similarity(semantic.copy())
    diff = float(np.max(np.abs(original_dist - erased_dist)))
    return {
        "max_distance_change": diff,
        "relation_kernel_jaccard": 1.0 if diff < 1e-12 else 0.0,
        "concept_erasure_pass": bool(diff < 1e-12),
    }
