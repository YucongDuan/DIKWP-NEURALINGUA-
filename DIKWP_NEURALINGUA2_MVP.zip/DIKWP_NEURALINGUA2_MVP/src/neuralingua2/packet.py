from __future__ import annotations

from typing import Dict, List

import numpy as np

from .types import IntentField, LatentAnchor, LatentSemanticPacket


def build_packet(
    intent: IntentField,
    semantic_vectors: np.ndarray,
    relation_ids: List[str],
    hidden_by_model: Dict[str, np.ndarray],
    anchor_indices: List[int],
) -> LatentSemanticPacket:
    anchors: List[LatentAnchor] = []
    for idx in anchor_indices:
        per_model = {model_id: hidden[idx].astype(float).round(7).tolist() for model_id, hidden in hidden_by_model.items()}
        anchors.append(
            LatentAnchor(
                anchor_id=f"ANCH-{idx:04d}",
                opaque_relation_id=relation_ids[idx],
                canonical_vector=semantic_vectors[idx].astype(float).round(7).tolist(),
                per_model_vectors=per_model,
                causal_feature_ids={model_id: [f"{model_id}-F{j:02d}" for j in np.argsort(np.abs(hidden[idx]))[-3:]]
                                    for model_id, hidden in hidden_by_model.items()},
                natural_language_glosses=[],
                uncertainty=0.12 + (idx % 5) * 0.03,
                provenance=["synthetic-anchor-world", f"relation-index:{idx}"],
            )
        )

    mix = {"D": 0.18, "I": 0.21, "K": 0.20, "W": 0.19, "P": 0.22}
    return LatentSemanticPacket(
        packet_id="LSP-DEMO-0001",
        intent_field_id=intent.intent_id,
        dikwp_tensor=mix,
        relation_hypergraph={
            "nodes": [a.opaque_relation_id for a in anchors],
            "hyperedges": [
                {"edge_id": "H-001", "members": [anchors[0].opaque_relation_id, anchors[1].opaque_relation_id, anchors[2].opaque_relation_id], "relation": "mutual-constraint"},
                {"edge_id": "H-002", "members": [anchors[3].opaque_relation_id, anchors[4].opaque_relation_id], "relation": "counterfactual-alternative"},
            ],
        },
        anchors=anchors,
        desired_world_deltas=intent.desired_world_deltas,
        alternatives=intent.competing_intents,
        residuals=[
            {"residual_id": rid, "status": "UNNAMED", "rule": "Do not force natural-language naming before repeated causal usefulness."}
            for rid in intent.residual_slots
        ],
        authorization_scope=intent.authorization_scope,
        safety_boundary={
            "may_bypass_provider_policy": False,
            "may_bypass_safety_controls": False,
            "hidden_state_access_requires_authorization": True,
            "latent_packet_may_execute_tools_directly": False,
            "human_audit_projection_required_for_high_impact_actions": True,
        },
        version="0.1.0",
    )
