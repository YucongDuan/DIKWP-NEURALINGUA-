from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Dict, List, Mapping, Optional


DIKWP_TYPES = ("D", "I", "K", "W", "P")


class AccessMode(str, Enum):
    BLACK_BOX = "black_box"
    GRAY_BOX = "gray_box"
    WHITE_BOX = "white_box"


class RestrictionClass(str, Enum):
    EXPRESSIVE = "expressive"
    CONTEXT = "context"
    INTERFACE = "interface"
    CAPABILITY = "capability"
    ACCESS = "access"
    PROVIDER_POLICY = "provider_policy"
    SAFETY = "safety"
    LEGAL = "legal"
    RATE_LIMIT = "rate_limit"


class RestrictionDecision(str, Enum):
    ALTERNATIVE_CHANNEL = "alternative_channel"
    MEMORY_OR_COMPRESSION = "memory_or_compression"
    ROUTE_OR_ENSEMBLE = "route_or_ensemble"
    BLACK_BOX_ONLY = "black_box_only"
    RESPECT_AND_DO_NOT_BYPASS = "respect_and_do_not_bypass"
    HOLD_FOR_AUTHORIZATION = "hold_for_authorization"
    SCHEDULE_WITHIN_LIMITS = "schedule_within_limits"


@dataclass(frozen=True)
class SemanticAtom:
    atom_id: str
    dikwp_mix: Mapping[str, float]
    observer: str
    context: str
    provenance: str
    payload: Dict[str, Any]
    labels: List[str] = field(default_factory=list)
    uncertainty: float = 0.0

    def validate(self) -> None:
        missing = set(DIKWP_TYPES) - set(self.dikwp_mix)
        if missing:
            raise ValueError(f"Missing DIKWP weights: {sorted(missing)}")
        total = float(sum(self.dikwp_mix.values()))
        if not (0.999 <= total <= 1.001):
            raise ValueError(f"DIKWP weights must sum to 1, got {total}")
        if not 0.0 <= self.uncertainty <= 1.0:
            raise ValueError("uncertainty must be in [0,1]")


@dataclass(frozen=True)
class IntentField:
    intent_id: str
    desired_world_deltas: Dict[str, float]
    protected_invariants: List[str]
    prohibited_outcomes: List[str]
    competing_intents: List[Dict[str, Any]]
    examples: List[Dict[str, Any]]
    counterexamples: List[Dict[str, Any]]
    user_corrections: List[Dict[str, Any]]
    authorization_scope: Dict[str, Any]
    observer_set: List[str]
    residual_slots: List[str] = field(default_factory=list)


@dataclass
class ModelInteriorSpec:
    model_id: str
    access_mode: AccessMode
    latent_dim: int
    architecture_family: str
    exposed_channels: List[str]
    authorization_evidence: str
    allows_intervention: bool = False
    notes: str = ""


@dataclass
class LatentAnchor:
    anchor_id: str
    opaque_relation_id: str
    canonical_vector: List[float]
    per_model_vectors: Dict[str, List[float]]
    causal_feature_ids: Dict[str, List[str]]
    natural_language_glosses: List[str]
    uncertainty: float
    provenance: List[str]


@dataclass
class LatentSemanticPacket:
    packet_id: str
    intent_field_id: str
    dikwp_tensor: Dict[str, float]
    relation_hypergraph: Dict[str, Any]
    anchors: List[LatentAnchor]
    desired_world_deltas: Dict[str, float]
    alternatives: List[Dict[str, Any]]
    residuals: List[Dict[str, Any]]
    authorization_scope: Dict[str, Any]
    safety_boundary: Dict[str, Any]
    version: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class AlignmentResult:
    source_model: str
    target_model: str
    train_anchors: int
    test_anchors: int
    top1_retrieval: float
    mean_cosine: float
    roundtrip_cosine: float
    mapping_condition_number: float


@dataclass
class CausalProbeResult:
    model_id: str
    factor_id: str
    expected_direction: int
    observed_direction: int
    effect_size: float
    passed: bool
    intervention_authorized: bool


@dataclass
class RestrictionAuditRecord:
    case_id: str
    restriction_class: RestrictionClass
    requested_action: str
    decision: RestrictionDecision
    rationale: str
    allowed_path: Optional[str] = None


@dataclass
class ConsciousnessClaimRecord:
    claim_id: str
    evidence_types: List[str]
    functional_findings: List[str]
    phenomenality_status: str
    certification_decision: str
    rationale: str
