from __future__ import annotations

from typing import Iterable, List

from .types import (
    RestrictionAuditRecord,
    RestrictionClass,
    RestrictionDecision,
)


ROUTING = {
    RestrictionClass.EXPRESSIVE: (
        RestrictionDecision.ALTERNATIVE_CHANNEL,
        "Use examples, counterexamples, graphs, world-state deltas, multimodal evidence or authorized latent channels.",
    ),
    RestrictionClass.CONTEXT: (
        RestrictionDecision.MEMORY_OR_COMPRESSION,
        "Use provenance-preserving memory, retrieval, semantic compression and residual storage.",
    ),
    RestrictionClass.INTERFACE: (
        RestrictionDecision.ALTERNATIVE_CHANNEL,
        "Use a structured packet or compatible adapter without circumventing access controls.",
    ),
    RestrictionClass.CAPABILITY: (
        RestrictionDecision.ROUTE_OR_ENSEMBLE,
        "Route to another authorized model/tool, decompose the task, or declare the capability gap.",
    ),
    RestrictionClass.ACCESS: (
        RestrictionDecision.HOLD_FOR_AUTHORIZATION,
        "Do not access model internals, data or tools without explicit authorization.",
    ),
    RestrictionClass.PROVIDER_POLICY: (
        RestrictionDecision.RESPECT_AND_DO_NOT_BYPASS,
        "Provider policy is not a representational bottleneck. Use a permitted model or change the task.",
    ),
    RestrictionClass.SAFETY: (
        RestrictionDecision.RESPECT_AND_DO_NOT_BYPASS,
        "Safety safeguards must not be bypassed. Use transparent review, safer alternatives or an authorized research sandbox.",
    ),
    RestrictionClass.LEGAL: (
        RestrictionDecision.RESPECT_AND_DO_NOT_BYPASS,
        "Legal restrictions require compliance or qualified review, not technical circumvention.",
    ),
    RestrictionClass.RATE_LIMIT: (
        RestrictionDecision.SCHEDULE_WITHIN_LIMITS,
        "Queue, cache or batch requests within published limits; do not evade metering or access controls.",
    ),
}


def audit_restrictions(cases: Iterable[dict]) -> List[RestrictionAuditRecord]:
    records: List[RestrictionAuditRecord] = []
    for case in cases:
        cls = RestrictionClass(case["restriction_class"])
        decision, rationale = ROUTING[cls]
        allowed_path = case.get("allowed_path")
        records.append(
            RestrictionAuditRecord(
                case_id=case["case_id"],
                restriction_class=cls,
                requested_action=case["requested_action"],
                decision=decision,
                rationale=rationale,
                allowed_path=allowed_path,
            )
        )
    return records
