from __future__ import annotations

import argparse
import json
from pathlib import Path

from .run import run_demo


def main() -> None:
    parser = argparse.ArgumentParser(description="DIKWP-NEURALINGUA² offline reference runtime")
    sub = parser.add_subparsers(dest="command", required=True)
    run_parser = sub.add_parser("run", help="run deterministic synthetic demonstration")
    run_parser.add_argument("--seed", type=int, default=20260720)
    run_parser.add_argument("--out", type=Path, default=Path("outputs"))
    args = parser.parse_args()

    if args.command == "run":
        root = Path(__file__).resolve().parents[2]
        metrics = run_demo(args.seed, root, args.out)
        print(json.dumps(metrics["summary"], ensure_ascii=False, indent=2))
        print(f"Dashboard: {args.out / 'dashboard.html'}")


if __name__ == "__main__":
    main()
