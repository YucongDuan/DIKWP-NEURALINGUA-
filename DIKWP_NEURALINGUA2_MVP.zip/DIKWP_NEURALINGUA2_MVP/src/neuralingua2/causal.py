from __future__ import annotations

from typing import Iterable, List

import numpy as np

from .synthetic import SyntheticInteriorModel
from .types import CausalProbeResult


def run_causal_probes(
    models: Iterable[SyntheticInteriorModel],
    semantic_vectors: np.ndarray,
    rng: np.random.Generator,
) -> List[CausalProbeResult]:
    results: List[CausalProbeResult] = []
    probe_factors = [0, 3, 7]
    sample = semantic_vectors[:24]
    for model in models:
        hidden = model.encode(sample, rng=None)
        baseline = model.action_logits(hidden).mean(axis=0)
        for factor in probe_factors:
            direction = model.factor_direction(factor)
            # Both positive and negative interventions are compared; intervention only allowed for white-box adapters.
            scale = 1.15
            plus = model.action_logits(hidden + scale * direction).mean(axis=0)
            minus = model.action_logits(hidden - scale * direction).mean(axis=0)
            effect = plus - minus
            target_action = int(np.argmax(np.abs(effect)))
            observed_direction = int(np.sign(effect[target_action]))
            # Expected direction comes from a numerically estimated derivative, not a semantic label.
            epsilon = 0.05
            local_plus = model.action_logits(hidden + epsilon * direction).mean(axis=0)
            local_minus = model.action_logits(hidden - epsilon * direction).mean(axis=0)
            expected_direction = int(np.sign((local_plus - local_minus)[target_action]))
            passed = observed_direction == expected_direction and abs(effect[target_action]) > 0.05
            results.append(
                CausalProbeResult(
                    model_id=model.spec.model_id,
                    factor_id=f"FAC-{factor:02d}",
                    expected_direction=expected_direction,
                    observed_direction=observed_direction,
                    effect_size=float(effect[target_action]),
                    passed=bool(passed),
                    intervention_authorized=model.spec.allows_intervention,
                )
            )
    return results
