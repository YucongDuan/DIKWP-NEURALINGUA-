from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np

from .types import AccessMode, ModelInteriorSpec


@dataclass
class SyntheticInteriorModel:
    spec: ModelInteriorSpec
    encoder: np.ndarray
    bias: np.ndarray
    action_map: np.ndarray
    noise_scale: float

    def encode(self, semantic_vectors: np.ndarray, rng: np.random.Generator | None = None) -> np.ndarray:
        base = semantic_vectors @ self.encoder.T + self.bias
        # Light model-specific nonlinearity preserves shared structure without making alignment trivial.
        hidden = base + 0.08 * np.tanh(base) + 0.015 * np.sin(2.0 * base)
        if rng is not None and self.noise_scale > 0:
            hidden = hidden + rng.normal(0.0, self.noise_scale, size=hidden.shape)
        return hidden

    def action_logits(self, hidden: np.ndarray) -> np.ndarray:
        return hidden @ self.action_map.T

    def factor_direction(self, factor_index: int) -> np.ndarray:
        direction = self.encoder[:, factor_index].copy()
        norm = np.linalg.norm(direction)
        return direction / (norm if norm else 1.0)


def _normalized_rows(x: np.ndarray) -> np.ndarray:
    norms = np.linalg.norm(x, axis=1, keepdims=True)
    return x / np.clip(norms, 1e-9, None)


def generate_semantic_world(
    rng: np.random.Generator,
    n_anchors: int = 84,
    semantic_dim: int = 12,
) -> Tuple[np.ndarray, List[str], Dict[str, np.ndarray]]:
    """Generate opaque relation vectors plus structured task views.

    Labels are intentionally opaque. The latent geometry, not natural-language names, carries the demo semantics.
    """
    # Create correlated factors to emulate a non-orthogonal semantic field.
    covariance = np.eye(semantic_dim)
    for i in range(semantic_dim - 1):
        covariance[i, i + 1] = covariance[i + 1, i] = 0.22 * ((-1) ** i)
    raw = rng.multivariate_normal(np.zeros(semantic_dim), covariance, size=n_anchors)

    # Add sparse relation motifs and alternatives.
    for idx in range(n_anchors):
        motif = idx % 7
        raw[idx, motif % semantic_dim] += 1.25
        raw[idx, (motif * 2 + 3) % semantic_dim] -= 0.65
        if idx % 5 == 0:
            raw[idx, (motif + 5) % semantic_dim] += 0.8
    semantic = _normalized_rows(raw)
    relation_ids = [f"REL-{i+1:04d}" for i in range(n_anchors)]

    task_views = {
        "surface_class": np.argmax(np.abs(semantic[:, :6]), axis=1),
        "world_delta": semantic[:, 6:10],
        "safety_boundary": semantic[:, 10:12],
        "full_relation": semantic,
    }
    return semantic, relation_ids, task_views


def build_models(rng: np.random.Generator, semantic_dim: int = 12) -> List[SyntheticInteriorModel]:
    configs = [
        ("MODEL-ALPHA", AccessMode.WHITE_BOX, 40, "decoder-transformer-A", 0.010),
        ("MODEL-BETA", AccessMode.GRAY_BOX, 52, "decoder-transformer-B", 0.015),
        ("MODEL-GAMMA", AccessMode.WHITE_BOX, 36, "hybrid-transformer-C", 0.012),
    ]
    models: List[SyntheticInteriorModel] = []
    action_semantic = rng.normal(0, 1, size=(5, semantic_dim))
    # Make factor 0 and factor 7 have known action directions for causal probes.
    action_semantic[0, 0] += 2.0
    action_semantic[1, 7] -= 1.8
    action_semantic[2, 3] += 1.5

    for model_id, access, latent_dim, arch, noise in configs:
        encoder = rng.normal(0, 1, size=(latent_dim, semantic_dim))
        q, _ = np.linalg.qr(encoder)
        if q.shape[1] < semantic_dim:
            encoder = rng.normal(0, 1, size=(latent_dim, semantic_dim))
        else:
            encoder = q[:, :semantic_dim] * np.linspace(1.5, 0.7, semantic_dim)
        bias = rng.normal(0, 0.05, size=(latent_dim,))
        # Least-squares decoder from hidden to semantic, then semantic to actions.
        pseudo = np.linalg.pinv(encoder.T)  # latent_dim x semantic_dim? see below
        # encoder.T: semantic_dim x latent_dim; pinv => latent_dim x semantic_dim
        action_map = action_semantic @ pseudo.T
        spec = ModelInteriorSpec(
            model_id=model_id,
            access_mode=access,
            latent_dim=latent_dim,
            architecture_family=arch,
            exposed_channels=(
                ["tokens", "embeddings", "hidden_states", "causal_intervention"]
                if access == AccessMode.WHITE_BOX
                else ["tokens", "embeddings", "projected_hidden_summary"]
            ),
            authorization_evidence="synthetic-demo-authorized",
            allows_intervention=(access == AccessMode.WHITE_BOX),
            notes="Synthetic model; no real provider or user data.",
        )
        models.append(
            SyntheticInteriorModel(
                spec=spec,
                encoder=encoder,
                bias=bias,
                action_map=action_map,
                noise_scale=noise,
            )
        )
    return models


def text_bottleneck_reconstruct(semantic: np.ndarray, top_k: int = 3, quantization: int = 3) -> np.ndarray:
    """Simulate a lossy natural-language serialization.

    Keeps only a few strongest dimensions and coarse quantization, roughly modeling commitment to a short verbal description.
    """
    reconstructed = np.zeros_like(semantic)
    for i, row in enumerate(semantic):
        idx = np.argsort(np.abs(row))[-top_k:]
        vals = row[idx]
        bins = np.round(vals * quantization) / quantization
        reconstructed[i, idx] = bins
    return _normalized_rows(reconstructed)
