from __future__ import annotations

from typing import Iterable

from .types import ConsciousnessClaimRecord


FUNCTIONAL_EVIDENCE = {
    "activation_alignment",
    "causal_feature_intervention",
    "workspace_like_broadcast",
    "self_report",
    "metacognitive_calibration",
    "long_term_identity",
    "latent_channel_coherence",
}


def assess_consciousness_claim(claim_id: str, evidence_types: Iterable[str]) -> ConsciousnessClaimRecord:
    evidence = sorted(set(evidence_types))
    functional = [e for e in evidence if e in FUNCTIONAL_EVIDENCE]
    return ConsciousnessClaimRecord(
        claim_id=claim_id,
        evidence_types=evidence,
        functional_findings=functional,
        phenomenality_status="UNRESOLVED_PHI_RESIDUAL",
        certification_decision="NO_PHENOMENAL_CONSCIOUSNESS_CERTIFICATION",
        rationale=(
            "Latent activations, reportability, workspace-like organization, self-report and causal interventions can support "
            "functional claims. They do not establish first-person phenomenal experience or a transferable private consciousness space."
        ),
    )
