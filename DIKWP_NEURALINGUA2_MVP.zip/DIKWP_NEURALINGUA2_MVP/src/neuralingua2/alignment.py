from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from typing import Dict, Iterable, List, Tuple

import numpy as np
from scipy.linalg import orthogonal_procrustes
from sklearn.decomposition import PCA
from sklearn.metrics.pairwise import cosine_similarity

from .synthetic import SyntheticInteriorModel
from .types import AlignmentResult


@dataclass
class AlignmentModel:
    source_mean: np.ndarray
    target_mean: np.ndarray
    source_pca: PCA
    target_pca: PCA
    rotation: np.ndarray

    def map_source_to_target_common(self, source_hidden: np.ndarray) -> np.ndarray:
        src = self.source_pca.transform(source_hidden - self.source_mean)
        return src @ self.rotation

    def target_common(self, target_hidden: np.ndarray) -> np.ndarray:
        return self.target_pca.transform(target_hidden - self.target_mean)


def fit_alignment(
    source_hidden: np.ndarray,
    target_hidden: np.ndarray,
    train_indices: np.ndarray,
    common_dim: int = 12,
) -> AlignmentModel:
    k = min(common_dim, source_hidden.shape[1], target_hidden.shape[1], len(train_indices) - 1)
    source_mean = source_hidden[train_indices].mean(axis=0, keepdims=True)
    target_mean = target_hidden[train_indices].mean(axis=0, keepdims=True)
    source_pca = PCA(n_components=k, random_state=0)
    target_pca = PCA(n_components=k, random_state=0)
    xs = source_pca.fit_transform(source_hidden[train_indices] - source_mean)
    xt = target_pca.fit_transform(target_hidden[train_indices] - target_mean)
    xs = xs / np.clip(np.linalg.norm(xs, axis=1, keepdims=True), 1e-9, None)
    xt = xt / np.clip(np.linalg.norm(xt, axis=1, keepdims=True), 1e-9, None)
    rotation, _ = orthogonal_procrustes(xs, xt)
    return AlignmentModel(source_mean, target_mean, source_pca, target_pca, rotation)


def evaluate_alignment(
    source_id: str,
    target_id: str,
    alignment: AlignmentModel,
    source_hidden: np.ndarray,
    target_hidden: np.ndarray,
    train_indices: np.ndarray,
    test_indices: np.ndarray,
) -> AlignmentResult:
    mapped = alignment.map_source_to_target_common(source_hidden[test_indices])
    target = alignment.target_common(target_hidden[test_indices])
    mapped = mapped / np.clip(np.linalg.norm(mapped, axis=1, keepdims=True), 1e-9, None)
    target = target / np.clip(np.linalg.norm(target, axis=1, keepdims=True), 1e-9, None)
    sim = cosine_similarity(mapped, target)
    top1 = float(np.mean(np.argmax(sim, axis=1) == np.arange(len(test_indices))))
    mean_cos = float(np.mean(np.diag(sim)))

    # Approximate round trip using the transpose of the orthogonal map in common coordinates.
    roundtrip = mapped @ alignment.rotation.T @ alignment.rotation
    roundtrip_cos = float(np.mean(np.sum(mapped * roundtrip, axis=1) /
                                  np.clip(np.linalg.norm(mapped, axis=1) * np.linalg.norm(roundtrip, axis=1), 1e-9, None)))
    condition = float(np.linalg.cond(alignment.rotation))
    return AlignmentResult(
        source_model=source_id,
        target_model=target_id,
        train_anchors=len(train_indices),
        test_anchors=len(test_indices),
        top1_retrieval=top1,
        mean_cosine=mean_cos,
        roundtrip_cosine=roundtrip_cos,
        mapping_condition_number=condition,
    )


def align_all_models(
    models: Iterable[SyntheticInteriorModel],
    hidden_by_model: Dict[str, np.ndarray],
    train_indices: np.ndarray,
    test_indices: np.ndarray,
) -> Tuple[List[AlignmentResult], Dict[Tuple[str, str], AlignmentModel]]:
    model_list = list(models)
    results: List[AlignmentResult] = []
    mappings: Dict[Tuple[str, str], AlignmentModel] = {}
    for source, target in combinations(model_list, 2):
        fit = fit_alignment(
            hidden_by_model[source.spec.model_id],
            hidden_by_model[target.spec.model_id],
            train_indices,
        )
        result = evaluate_alignment(
            source.spec.model_id,
            target.spec.model_id,
            fit,
            hidden_by_model[source.spec.model_id],
            hidden_by_model[target.spec.model_id],
            train_indices,
            test_indices,
        )
        mappings[(source.spec.model_id, target.spec.model_id)] = fit
        results.append(result)
    return results, mappings
