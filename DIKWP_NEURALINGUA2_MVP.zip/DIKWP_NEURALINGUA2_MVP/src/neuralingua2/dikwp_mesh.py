from __future__ import annotations

from dataclasses import dataclass
from itertools import product
from typing import Dict, Iterable, List, Tuple

import networkx as nx

from .types import DIKWP_TYPES, SemanticAtom


@dataclass(frozen=True)
class Transformation:
    source_type: str
    target_type: str
    observer: str
    context: str
    purpose_field: str
    provenance: str
    reversible: bool
    operator_note: str

    @property
    def key(self) -> str:
        return f"{self.source_type}->{self.target_type}"


class DIKWPMesh:
    """Co-equal DIKWP multigraph with all 25 ordered transformations."""

    def __init__(self) -> None:
        self.graph = nx.MultiDiGraph()
        for t in DIKWP_TYPES:
            self.graph.add_node(t, resource_type=t)
        self.registry: Dict[str, Transformation] = {}
        self._register_primitive_alphabet()
        self.atoms: Dict[str, SemanticAtom] = {}

    def _register_primitive_alphabet(self) -> None:
        for src, dst in product(DIKWP_TYPES, repeat=2):
            reversible = src != dst
            note = self._default_note(src, dst)
            tx = Transformation(
                source_type=src,
                target_type=dst,
                observer="runtime",
                context="generic",
                purpose_field="distributed",
                provenance="primitive-alphabet",
                reversible=reversible,
                operator_note=note,
            )
            self.registry[tx.key] = tx
            self.graph.add_edge(src, dst, key=tx.key, **tx.__dict__)

    @staticmethod
    def _default_note(src: str, dst: str) -> str:
        if src == dst:
            return f"Revise, split, merge or re-index {src} without presuming a hierarchy."
        return f"Transform {src}-typed semantic resources into {dst}-typed resources under observer, context and intent indices."

    def add_atom(self, atom: SemanticAtom) -> None:
        atom.validate()
        self.atoms[atom.atom_id] = atom

    def coverage(self) -> float:
        expected = {f"{a}->{b}" for a, b in product(DIKWP_TYPES, repeat=2)}
        return len(expected.intersection(self.registry)) / len(expected)

    def cycle_count(self) -> int:
        simple = nx.DiGraph(self.graph)
        return sum(1 for _ in nx.simple_cycles(simple))

    def route(self, source_types: Iterable[str], target_type: str, cutoff: int = 4) -> List[List[str]]:
        simple = nx.DiGraph(self.graph)
        paths: List[List[str]] = []
        for src in source_types:
            for path in nx.all_simple_paths(simple, src, target_type, cutoff=cutoff):
                paths.append(path)
        return sorted(paths, key=lambda p: (len(p), p))

    def hierarchy_leakage_audit(self) -> Dict[str, object]:
        missing = []
        for a, b in product(DIKWP_TYPES, repeat=2):
            if f"{a}->{b}" not in self.registry:
                missing.append(f"{a}->{b}")
        only_forward = all(k in self.registry for k in ["D->I", "I->K", "K->W", "W->P"]) and any(missing)
        purpose_incoming = [k for k in self.registry if k.endswith("->P")]
        purpose_outgoing = [k for k in self.registry if k.startswith("P->")]
        problems: List[str] = []
        if missing:
            problems.append(f"missing {len(missing)} primitive transformations")
        if only_forward:
            problems.append("network may collapse into a D→I→K→W→P traversal")
        if len(purpose_outgoing) < 5 or len(purpose_incoming) < 5:
            problems.append("Purpose is insufficiently revisable/distributed")
        return {
            "coverage": self.coverage(),
            "cycle_count": self.cycle_count(),
            "missing": missing,
            "problems": problems,
            "status": "NETWORK_COMPATIBLE" if not problems else "REVIEW",
        }
