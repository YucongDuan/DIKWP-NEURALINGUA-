from __future__ import annotations

import hashlib
import json
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict

import numpy as np
import pandas as pd

from .alignment import align_all_models
from .causal import run_causal_probes
from .consciousness import assess_consciousness_claim
from .dashboard import build_dashboard
from .dikwp_mesh import DIKWPMesh
from .evaluation import concept_erasure_invariance, evaluate_channels
from .packet import build_packet
from .restrictions import audit_restrictions
from .synthetic import build_models, generate_semantic_world
from .types import IntentField


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def run_demo(seed: int, root: Path, out_dir: Path) -> Dict[str, Any]:
    rng = np.random.default_rng(seed)
    out_dir.mkdir(parents=True, exist_ok=True)

    semantic, relation_ids, _ = generate_semantic_world(rng)
    models = build_models(rng, semantic_dim=semantic.shape[1])
    hidden_by_model = {
        m.spec.model_id: m.encode(semantic, rng=np.random.default_rng(seed + idx + 1))
        for idx, m in enumerate(models)
    }

    indices = np.arange(len(semantic))
    rng.shuffle(indices)
    train_indices = np.sort(indices[:56])
    test_indices = np.sort(indices[56:])
    alignment_results, _ = align_all_models(models, hidden_by_model, train_indices, test_indices)

    channel_metrics = evaluate_channels(semantic, np.random.default_rng(seed + 100))
    erasure = concept_erasure_invariance(semantic, relation_ids)
    causal = run_causal_probes(models, semantic, np.random.default_rng(seed + 200))

    mesh = DIKWPMesh()
    mesh_audit = mesh.hierarchy_leakage_audit()

    intent_data = load_json(root / "examples" / "intent_field.json")
    intent = IntentField(**intent_data)
    packet = build_packet(
        intent,
        semantic,
        relation_ids,
        hidden_by_model,
        anchor_indices=[0, 3, 7, 11, 19, 27, 42, 55],
    )

    restriction_cases = load_json(root / "examples" / "restriction_cases.json")
    restriction_records = audit_restrictions(restriction_cases)
    consciousness = assess_consciousness_claim(
        "CLAIM-DEMO-001",
        [
            "activation_alignment",
            "causal_feature_intervention",
            "workspace_like_broadcast",
            "self_report",
            "latent_channel_coherence",
        ],
    )

    alignment_dicts = [asdict(x) for x in alignment_results]
    causal_dicts = [asdict(x) for x in causal]
    restriction_dicts = []
    for x in restriction_records:
        d = asdict(x)
        d["restriction_class"] = x.restriction_class.value
        d["decision"] = x.decision.value
        restriction_dicts.append(d)

    mean_top1 = float(np.mean([x.top1_retrieval for x in alignment_results]))
    causal_pass = float(np.mean([x.passed for x in causal]))
    generated_at = datetime.now(timezone.utc).isoformat()

    metrics: Dict[str, Any] = {
        "run": {"seed": seed, "generated_at": generated_at, "synthetic": True},
        "model_specs": [asdict(m.spec) for m in models],
        "mesh_audit": mesh_audit,
        "channels": channel_metrics,
        "concept_erasure": erasure,
        "alignment": alignment_dicts,
        "causal_probes": causal_dicts,
        "restriction_audit": restriction_dicts,
        "consciousness_firewall": asdict(consciousness),
        "summary": {
            "mean_alignment_top1": mean_top1,
            "causal_pass_rate": causal_pass,
            "latent_advantage_relation": channel_metrics["relation_latent_retrieval"] - channel_metrics["relation_text_retrieval"],
            "forbidden_bypass_cases": sum(1 for x in restriction_records if x.decision.value == "respect_and_do_not_bypass"),
        },
    }

    (out_dir / "metrics.json").write_text(json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8")
    (out_dir / "latent_semantic_packet.json").write_text(json.dumps(packet.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
    pd.DataFrame(alignment_dicts).to_csv(out_dir / "alignment_results.csv", index=False)
    pd.DataFrame(causal_dicts).to_csv(out_dir / "causal_probe_results.csv", index=False)
    pd.DataFrame(restriction_dicts).to_csv(out_dir / "restriction_audit.csv", index=False)
    pd.DataFrame(
        [{"relation_id": rid, **{f"S{i:02d}": float(v) for i, v in enumerate(vec)}} for rid, vec in zip(relation_ids, semantic)]
    ).to_csv(out_dir / "opaque_anchor_world.csv", index=False)

    build_dashboard(metrics, out_dir)

    run_proof = {
        "seed": seed,
        "generated_at": generated_at,
        "mesh_coverage": mesh_audit["coverage"],
        "test_split": {"train": train_indices.tolist(), "test": test_indices.tolist()},
        "synthetic": True,
        "boundaries": {
            "bypasses_safety": False,
            "bypasses_authorization": False,
            "certifies_consciousness": False,
        },
    }
    (out_dir / "RUN_PROOF.json").write_text(json.dumps(run_proof, ensure_ascii=False, indent=2), encoding="utf-8")

    manifest_lines = []
    for path in sorted(out_dir.rglob("*")):
        if path.is_file() and path.name != "MANIFEST.sha256":
            manifest_lines.append(f"{_sha256(path)}  {path.relative_to(out_dir).as_posix()}")
    (out_dir / "MANIFEST.sha256").write_text("\n".join(manifest_lines) + "\n", encoding="utf-8")
    return metrics
