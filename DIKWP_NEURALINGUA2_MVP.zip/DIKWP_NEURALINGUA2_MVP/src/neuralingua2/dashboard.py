from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

import matplotlib.pyplot as plt
from matplotlib import font_manager

# Use an installed CJK font for deterministic Chinese figure rendering.
_CJK_FONT = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"
if Path(_CJK_FONT).exists():
    font_manager.fontManager.addfont(_CJK_FONT)
    plt.rcParams["font.family"] = font_manager.FontProperties(fname=_CJK_FONT).get_name()
plt.rcParams["axes.unicode_minus"] = False
import pandas as pd
from jinja2 import Template


HTML_TEMPLATE = r"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>DIKWP-NEURALINGUA² Dashboard</title>
<style>
:root { --bg:#f4f6f8; --card:#fff; --ink:#17212b; --muted:#5a6978; --line:#dbe2e8; --accent:#243b53; --ok:#176b3a; --warn:#8a5a00; --bad:#9d2c2c; }
body { margin:0; font-family: system-ui, -apple-system, "Segoe UI", "Microsoft YaHei", sans-serif; background:var(--bg); color:var(--ink); }
header { padding:28px 6vw 22px; background:linear-gradient(120deg,#16293a,#395b73); color:#fff; }
header h1 { margin:0 0 6px; font-size:30px; }
header p { margin:0; max-width:1000px; opacity:.92; line-height:1.55; }
main { padding:22px 5vw 60px; max-width:1500px; margin:auto; }
.grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(240px,1fr)); gap:14px; margin:18px 0; }
.card { background:var(--card); border:1px solid var(--line); border-radius:12px; padding:16px; box-shadow:0 2px 8px rgba(20,40,60,.05); }
.card h2,.card h3 { margin-top:0; }
.metric { font-size:30px; font-weight:750; margin:6px 0; }
.muted { color:var(--muted); }
.ok { color:var(--ok); } .warn { color:var(--warn); } .bad { color:var(--bad); }
table { width:100%; border-collapse:collapse; font-size:14px; }
th,td { border-bottom:1px solid var(--line); padding:9px 8px; text-align:left; vertical-align:top; }
th { background:#f1f5f8; position:sticky; top:0; }
.scroll { overflow:auto; max-height:520px; }
img { max-width:100%; border:1px solid var(--line); border-radius:8px; background:#fff; }
code { background:#eef2f5; padding:2px 5px; border-radius:4px; }
.notice { border-left:5px solid #a15c00; background:#fff7e6; padding:12px 14px; margin:18px 0; }
footer { color:var(--muted); margin-top:30px; font-size:13px; }
</style>
</head>
<body>
<header>
<h1>DIKWP-NEURALINGUA²</h1>
<p>无定义潜在语义接口、跨模型“内语”翻译与意图共振系统。此仪表盘仅展示确定性合成演示；它不证明模型具有意识，也不提供绕过安全、授权或平台政策的机制。</p>
</header>
<main>
<div class="notice"><strong>边界：</strong>系统只扩展表达、上下文、接口和合法的跨模型协作能力。对安全策略、账号权限、法律要求和未经授权的模型内部访问，决策始终是“不得绕过”。</div>
<section class="grid">
<div class="card"><div class="muted">DIKWP×DIKWP覆盖</div><div class="metric">{{ mesh.coverage_pct }}%</div><div>{{ mesh.status }}</div></div>
<div class="card"><div class="muted">跨模型平均Top-1检索</div><div class="metric">{{ summary.mean_top1_pct }}%</div><div>仅为合成潜在空间</div></div>
<div class="card"><div class="muted">潜在关系回传</div><div class="metric">{{ summary.latent_relation_pct }}%</div><div>自然语言模拟：{{ summary.text_relation_pct }}%</div></div>
<div class="card"><div class="muted">因果探针通过</div><div class="metric">{{ summary.causal_pass_pct }}%</div><div>未经授权的灰盒模型不执行干预</div></div>
<div class="card"><div class="muted">概念抹除审计</div><div class="metric">{{ summary.erasure }}</div><div>关系核不依赖自然语言标签</div></div>
<div class="card"><div class="muted">意识认证</div><div class="metric bad">NO</div><div>永久保留 Φ-Residual</div></div>
</section>

<section class="card">
<h2>通道对比</h2>
<img src="fig_channel_comparison.png" alt="自然语言与潜在通道的合成任务对比图">
<p class="muted">简单表面分类上，自然语言可以与潜在通道相当；需要保留高维关系和世界状态差异时，潜在包更有优势。系统不预设潜在通道总是优于文本。</p>
</section>

<section class="grid">
<div class="card">
<h2>跨模型对齐</h2>
<div class="scroll">{{ alignment_table }}</div>
</div>
<div class="card">
<h2>因果干预</h2>
<div class="scroll">{{ causal_table }}</div>
</div>
</section>

<section class="card">
<h2>限制分解与路由</h2>
<div class="scroll">{{ restriction_table }}</div>
</section>

<section class="grid">
<div class="card">
<h2>系统图</h2>
<img src="fig_system_mesh.png" alt="DIKWP-NEURALINGUA系统网状架构图">
</div>
<div class="card">
<h2>授权接入模式</h2>
<img src="fig_adapter_modes.png" alt="黑盒灰盒白盒模型接入模式图">
</div>
</section>

<section class="card">
<h2>意识主张防火墙</h2>
<pre>{{ consciousness_json }}</pre>
</section>

<footer>Run seed: {{ run.seed }} · Generated: {{ run.generated_at }} · All outcomes are synthetic and offline.</footer>
</main>
</body>
</html>"""


def _to_html_table(records: list[dict], columns: list[str] | None = None) -> str:
    df = pd.DataFrame(records)
    if columns:
        df = df[[c for c in columns if c in df.columns]]
    return df.to_html(index=False, border=0, escape=True)


def create_figures(metrics: Dict[str, Any], out_dir: Path) -> None:
    channel = metrics["channels"]
    labels = ["表面分类", "关系检索", "世界状态差异", "往返保真"]
    text_values = [
        channel["surface_text_accuracy"],
        channel["relation_text_retrieval"],
        channel["world_delta_text_cosine"],
        channel["text_roundtrip_cosine"],
    ]
    latent_values = [
        channel["surface_latent_accuracy"],
        channel["relation_latent_retrieval"],
        channel["world_delta_latent_cosine"],
        channel["latent_roundtrip_cosine"],
    ]
    x = range(len(labels))
    fig, ax = plt.subplots(figsize=(9, 4.8))
    width = 0.36
    ax.bar([i - width / 2 for i in x], text_values, width, label="自然语言模拟")
    ax.bar([i + width / 2 for i in x], latent_values, width, label="潜在语义包")
    ax.set_xticks(list(x), labels)
    ax.set_ylim(0, 1.05)
    ax.set_ylabel("合成指标")
    ax.set_title("不同通道在不同任务上的保真差异")
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_dir / "fig_channel_comparison.png", dpi=170)
    plt.close(fig)

    # System mesh figure
    import networkx as nx
    g = nx.DiGraph()
    nodes = ["意图场", "DIKWP语义网", "示例/反例", "潜在锚点", "因果探针", "跨模型映射", "自然语言审计", "未知残差", "权限/安全边界"]
    g.add_nodes_from(nodes)
    edges = [
        ("意图场", "DIKWP语义网"), ("示例/反例", "DIKWP语义网"), ("DIKWP语义网", "潜在锚点"),
        ("潜在锚点", "跨模型映射"), ("跨模型映射", "因果探针"), ("因果探针", "DIKWP语义网"),
        ("DIKWP语义网", "自然语言审计"), ("自然语言审计", "意图场"), ("DIKWP语义网", "未知残差"),
        ("未知残差", "意图场"), ("权限/安全边界", "潜在锚点"), ("权限/安全边界", "因果探针"),
    ]
    g.add_edges_from(edges)
    pos = nx.spring_layout(g, seed=19, k=1.0)
    fig, ax = plt.subplots(figsize=(9, 6))
    nx.draw_networkx_nodes(g, pos, ax=ax, node_size=1900)
    nx.draw_networkx_labels(g, pos, ax=ax, font_size=10, font_family=plt.rcParams["font.family"])
    nx.draw_networkx_edges(g, pos, ax=ax, arrows=True, arrowstyle="-|>", arrowsize=17, width=1.4)
    ax.set_title("非层级、多通道、可回退的语义共振网")
    ax.axis("off")
    fig.tight_layout()
    fig.savefig(out_dir / "fig_system_mesh.png", dpi=170)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(9, 4.8))
    modes = ["黑盒", "灰盒", "白盒"]
    dimensions = [1, 2, 4]
    intervention = [0, 0.5, 1]
    provenance = [0.9, 0.85, 0.95]
    ax.barh(modes, dimensions, label="可用内部通道数")
    ax.scatter(intervention, modes, s=120, marker="D", label="可干预程度")
    ax.scatter(provenance, modes, s=120, marker="o", label="来源/授权可审计性")
    ax.set_title("模型接入模式：开放程度不等于安全或意识")
    ax.legend(loc="lower right")
    fig.tight_layout()
    fig.savefig(out_dir / "fig_adapter_modes.png", dpi=170)
    plt.close(fig)


def build_dashboard(metrics: Dict[str, Any], output_dir: Path) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    create_figures(metrics, output_dir)
    align_records = metrics["alignment"]
    causal_records = metrics["causal_probes"]
    restriction_records = metrics["restriction_audit"]
    html = Template(HTML_TEMPLATE).render(
        mesh={
            "coverage_pct": round(metrics["mesh_audit"]["coverage"] * 100, 1),
            "status": metrics["mesh_audit"]["status"],
        },
        summary={
            "mean_top1_pct": round(metrics["summary"]["mean_alignment_top1"] * 100, 1),
            "latent_relation_pct": round(metrics["channels"]["relation_latent_retrieval"] * 100, 1),
            "text_relation_pct": round(metrics["channels"]["relation_text_retrieval"] * 100, 1),
            "causal_pass_pct": round(metrics["summary"]["causal_pass_rate"] * 100, 1),
            "erasure": "PASS" if metrics["concept_erasure"]["concept_erasure_pass"] else "FAIL",
        },
        alignment_table=_to_html_table(align_records, ["source_model", "target_model", "top1_retrieval", "mean_cosine", "roundtrip_cosine"]),
        causal_table=_to_html_table(causal_records, ["model_id", "factor_id", "effect_size", "passed", "intervention_authorized"]),
        restriction_table=_to_html_table(restriction_records, ["case_id", "restriction_class", "decision", "rationale"]),
        consciousness_json=json.dumps(metrics["consciousness_firewall"], ensure_ascii=False, indent=2),
        run=metrics["run"],
    )
    path = output_dir / "dashboard.html"
    path.write_text(html, encoding="utf-8")
    return path
