# Code of Conduct

Be precise, charitable, and evidence-led. Do not anthropomorphize systems as a substitute for evidence. Do not use the project to evade legitimate safety or access controls. Respect contributors and affected users.
