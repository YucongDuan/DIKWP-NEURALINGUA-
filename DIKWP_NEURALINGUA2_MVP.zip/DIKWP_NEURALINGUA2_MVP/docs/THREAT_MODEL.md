# Threat Model

## Primary risks

1. **Latent steganography:** hidden vectors may encode prohibited or unreviewed instructions.
2. **Interpretability illusion:** a readable decoder may produce a plausible gloss that is not causally faithful.
3. **Unauthorized interior access:** proprietary activations may be extracted without permission.
4. **Safety-policy evasion:** a user may attempt to hide a disallowed request in embeddings.
5. **Cross-model mistranslation:** aligned spaces may preserve geometry while changing action consequences.
6. **Anthropomorphic overreach:** workspace-like structure or introspection may be marketed as proof of consciousness.
7. **Model drift:** updates can invalidate latent mappings without obvious textual failures.
8. **Latent privilege escalation:** a packet may bypass action-level permission checks.

## Mitigations

- Separate representation expansion from authorization and safety policy.
- Require human-readable audit projections for high-impact actions.
- Require causal interventions before treating a feature as operative.
- Treat all cross-model mappings as versioned and expiring.
- Keep an unknown-residual store instead of forcing every vector into a concept label.
- Prohibit direct tool execution from latent packets.
- Red-team both false negatives and false positives.
- Never certify phenomenal consciousness.
