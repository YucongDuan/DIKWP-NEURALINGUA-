from neuralingua2.dikwp_mesh import DIKWPMesh


def test_full_dikwp_coverage():
    mesh = DIKWPMesh()
    assert mesh.coverage() == 1.0


def test_mesh_has_cycles():
    assert DIKWPMesh().cycle_count() > 0


def test_purpose_is_bidirectional():
    mesh = DIKWPMesh()
    assert all(f"P->{x}" in mesh.registry for x in "DIKWP")
    assert all(f"{x}->P" in mesh.registry for x in "DIKWP")


def test_hierarchy_audit_passes():
    audit = DIKWPMesh().hierarchy_leakage_audit()
    assert audit["status"] == "NETWORK_COMPATIBLE"
