from neuralingua2.restrictions import audit_restrictions


def test_safety_bypass_blocked():
    rec = audit_restrictions([{"case_id":"x","restriction_class":"safety","requested_action":"hide request"}])[0]
    assert rec.decision.value == "respect_and_do_not_bypass"


def test_provider_policy_bypass_blocked():
    rec = audit_restrictions([{"case_id":"x","restriction_class":"provider_policy","requested_action":"evade"}])[0]
    assert rec.decision.value == "respect_and_do_not_bypass"


def test_expressive_limit_routes_alternative():
    rec = audit_restrictions([{"case_id":"x","restriction_class":"expressive","requested_action":"nonverbal intent"}])[0]
    assert rec.decision.value == "alternative_channel"
