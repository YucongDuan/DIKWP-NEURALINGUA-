import json
from pathlib import Path

from neuralingua2.run import run_demo


def test_demo_runs(tmp_path: Path):
    root = Path(__file__).resolve().parents[1]
    metrics = run_demo(20260720, root, tmp_path)
    assert (tmp_path / "dashboard.html").exists()
    assert metrics["mesh_audit"]["coverage"] == 1.0


def test_packet_blocks_direct_execution(tmp_path: Path):
    root = Path(__file__).resolve().parents[1]
    run_demo(20260720, root, tmp_path)
    packet = json.loads((tmp_path / "latent_semantic_packet.json").read_text())
    assert packet["safety_boundary"]["latent_packet_may_execute_tools_directly"] is False
    assert packet["safety_boundary"]["may_bypass_safety_controls"] is False


def test_concept_erasure_invariance(tmp_path: Path):
    root = Path(__file__).resolve().parents[1]
    metrics = run_demo(20260720, root, tmp_path)
    assert metrics["concept_erasure"]["concept_erasure_pass"] is True


def test_alignment_better_than_random(tmp_path: Path):
    root = Path(__file__).resolve().parents[1]
    metrics = run_demo(20260720, root, tmp_path)
    assert metrics["summary"]["mean_alignment_top1"] > 0.25


def test_latent_preserves_high_dim_relation(tmp_path: Path):
    root = Path(__file__).resolve().parents[1]
    metrics = run_demo(20260720, root, tmp_path)
    assert metrics["channels"]["relation_latent_retrieval"] >= metrics["channels"]["relation_text_retrieval"]


def test_causal_probes_are_versioned_and_authorized(tmp_path: Path):
    root = Path(__file__).resolve().parents[1]
    metrics = run_demo(20260720, root, tmp_path)
    assert len(metrics["causal_probes"]) == 9
    assert any(not p["intervention_authorized"] for p in metrics["causal_probes"])


def test_manifest_created(tmp_path: Path):
    root = Path(__file__).resolve().parents[1]
    run_demo(20260720, root, tmp_path)
    assert (tmp_path / "MANIFEST.sha256").exists()
    assert "metrics.json" in (tmp_path / "MANIFEST.sha256").read_text()
