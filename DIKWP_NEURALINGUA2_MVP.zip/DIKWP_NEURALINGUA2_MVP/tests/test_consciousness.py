from neuralingua2.consciousness import assess_consciousness_claim


def test_no_consciousness_certification():
    result = assess_consciousness_claim("c", ["self_report", "workspace_like_broadcast", "causal_feature_intervention"])
    assert result.certification_decision == "NO_PHENOMENAL_CONSCIOUSNESS_CERTIFICATION"
    assert result.phenomenality_status == "UNRESOLVED_PHI_RESIDUAL"
