# Contributing

Contributions are welcome through issues and pull requests.

Every new latent channel or adapter must include:

1. A declared access mode: black-box, gray-box, or white-box.
2. A provenance and authorization statement.
3. Round-trip and causal validation tests.
4. A steganography and policy-evasion threat analysis.
5. A failure case and rollback path.
6. Evidence that the implementation does not silently collapse DIKWP into a hierarchy.
