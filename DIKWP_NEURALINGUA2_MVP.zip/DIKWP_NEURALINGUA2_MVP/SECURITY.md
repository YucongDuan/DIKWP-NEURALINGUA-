# Security Policy

Report vulnerabilities privately to the repository maintainers before public disclosure.

## Explicitly out of scope

- Techniques for bypassing model-provider safety policies, account restrictions, authentication, authorization, or rate limits.
- Extraction of proprietary hidden states without permission.
- Covert latent channels designed to evade human or system oversight.
- Claims that latent coherence proves consciousness.

The reference runtime blocks requests categorized as authorization bypass or safety-control evasion.
