# Governance

The project is governed by maintainers, an independent safety reviewer, and an external replication editor.

No single role may simultaneously approve:

- model-interior access,
- latent-code deployment,
- causal-intervention interpretation,
- safety-policy boundary changes,
- and release certification.

Forks are legitimate. Evidence may travel; authorization does not.
